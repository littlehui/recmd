package chm.model;

import com.jfinal.plugin.activerecord.Model;


public class User extends Model<User>{
    /**
     * 
     */
    private static final long serialVersionUID=-2242227302031556023L;
    public static final User dao = new User();
}
